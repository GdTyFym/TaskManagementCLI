import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Task {
    public String title;
    public String description;
    public Date dueDate;
    public String status;

    public Task(String title, String description, Date dueDate) {
        this.title = title;
        this.description = description;
        this.dueDate = dueDate;
        this.status = "TODO";
    }

    @Override
    public String toString() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        return "Judul: " + title + "\n" +
                "Deskripsi: " + description + "\n" +
                "Batas Waktu: " + dateFormat.format(dueDate) + "\n" +
                "Status: " + status;
    }
}
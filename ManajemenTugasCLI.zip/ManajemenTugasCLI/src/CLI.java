import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class CLI {
    private final TaskList taskList;
    private final Scanner scanner;

    public CLI() {
        taskList = new TaskList();
        scanner = new Scanner(System.in);
    }

    private String loadLogo(String fileName) {
        StringBuilder logo = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                logo.append(line).append("\n");
            }
        } catch (IOException e) {
            System.err.println("Error membaca logo: " + e.getMessage());
        }
        return logo.toString();
    }

    public void run() {
        String logo = loadLogo("logo.txt"); // Load dan tampilkan logo
        System.out.println(logo);

        while (true) {
            displayMenu();
            int choice = getChoice();
            processChoice(choice);
        }
    }

    private void displayMenu() {
        System.out.println("\nMenu:");
        System.out.println("1. Tambah Tugas");
        System.out.println("2. Edit Tugas");
        System.out.println("3. Hapus Tugas");
        System.out.println("4. Lihat Tugas");
        System.out.println("5. Keluar");
    }

    private int getChoice() {
        System.out.print("Pilihan Anda: ");
        return scanner.nextInt();
    }

    private void processChoice(int choice) {
        switch (choice) {
            case 1:
                addTask();
                break;
            case 2:
                editTask();
                break;
            case 3:
                deleteTask();
                break;
            case 4:
                viewTasks();
                break;
            case 5:
                System.exit(0);
            default:
                System.out.println("Pilihan tidak valid.");
        }
    }

    private void addTask() {
        scanner.nextLine(); // Consume newline
        System.out.print("Judul: ");
        String title = scanner.nextLine();

        if (title.trim().isEmpty()) { // Validasi judul
            System.out.println("Judul tidak boleh kosong.");
            return;
        }

        System.out.print("Deskripsi: ");
        String description = scanner.nextLine();

        if (description.trim().isEmpty()) { // Validasi deskripsi
            System.out.println("Deskripsi tidak boleh kosong.");
            return;
        }

        System.out.print("Batas Waktu (YYYY-MM-DD): ");
        String dueDateString = scanner.nextLine();
        Date dueDate;
        try {
            dueDate = new SimpleDateFormat("yyyy-MM-dd").parse(dueDateString);
        } catch (ParseException e) {
            System.out.println("Format tanggal tidak valid. Gunakan YYYY-MM-DD.");
            return;
        }

        Task newTask = new Task(title, description, dueDate);
        taskList.addTask(newTask);
        System.out.println("Tugas ditambahkan.");
    }

    private void editTask() {
        System.out.print("Apakah Anda ingin melihat daftar tugas? (y/n): ");
        String viewChoice = scanner.next();
        if (viewChoice.equalsIgnoreCase("y")) {
            viewTasks();
        }

        System.out.print("Masukkan nomor tugas yang ingin diedit: ");
        int index = scanner.nextInt() - 1;
        if (index >= 0 && index < taskList.tasks.size()) {
            scanner.nextLine(); // Consume newline
            System.out.print("Judul baru: ");
            String newTitle = scanner.nextLine();
            System.out.print("Deskripsi baru: ");
            String newDescription = scanner.nextLine();
            System.out.print("Batas Waktu baru (YYYY-MM-DD): ");
            String newDueDateString = scanner.nextLine();
            Date newDueDate;
            try {
                newDueDate = new SimpleDateFormat("yyyy-MM-dd").parse(newDueDateString);
            } catch (ParseException e) {
                System.out.println("Format tanggal tidak valid. Gunakan YYYY-MM-DD.");
                return;
            }

            Task updatedTask = new Task(newTitle, newDescription, newDueDate);
            taskList.editTask(index, updatedTask);
            System.out.println("Tugas diperbarui.");
        } else {
            System.out.println("Nomor tugas tidak valid.");
        }
    }

    private void deleteTask() {
        System.out.print("Apakah Anda ingin melihat daftar tugas? (y/n): ");
        String viewChoice = scanner.next();
        if (viewChoice.equalsIgnoreCase("y")) {
            viewTasks();
        }

        System.out.print("Masukkan nomor tugas yang ingin dihapus: ");
        int index = scanner.nextInt() - 1;
        if (index >= 0 && index < taskList.tasks.size()) {
            System.out.print("Apakah Anda yakin ingin menghapus tugas ini? (y/n): ");
            String confirmChoice = scanner.next();
            if (confirmChoice.equalsIgnoreCase("y")) {
                taskList.deleteTask(index);
                System.out.println("Tugas dihapus.");
            } else {
                System.out.println("Penghapusan tugas dibatalkan.");
            }
        } else {
            System.out.println("Nomor tugas tidak valid.");
        }
    }

    private void viewTasks() {
        taskList.viewTasks();
    }

    public static void main(String[] args) {
        CLI cli = new CLI();
        cli.run();
    }
}
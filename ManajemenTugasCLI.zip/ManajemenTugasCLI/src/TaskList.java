import java.util.ArrayList;
import java.util.List;

public class TaskList {
    List<Task> tasks;

    public TaskList() {
        tasks = new ArrayList<>();
    }

    public void addTask(Task task) {
        tasks.add(task);
    }

    public void editTask(int index, Task updatedTask) {
        if (index >= 0 && index < tasks.size()) {
            tasks.set(index, updatedTask);
        } else {
            System.out.println("Tugas tidak ditemukan.");
        }
    }

    public void deleteTask(int index) {
        if (index >= 0 && index < tasks.size()) {
            tasks.remove(index);
        } else {
            System.out.println("Tugas tidak ditemukan.");
        }
    }

    public void viewTasks() {
        if (tasks.isEmpty()) {
            System.out.println("Tidak ada tugas.");
        } else {
            for (int i = 0; i < tasks.size(); i++) {
                System.out.println("Tugas " + (i + 1) + ":\n" + tasks.get(i));
            }
        }
    }

    // Implementasi saveTasks dan loadTasks (misalnya menggunakan file)
    // ...
}